"""Robust local JSON/CSV persistence and report generation."""
from __future__ import annotations
import csv, json, os, tempfile
from pathlib import Path
from datetime import datetime
from checklist import validate_record

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "records.json"
CSV_FILE = DATA_DIR / "records.csv"
BACKUP_FILE = DATA_DIR / "records.backup.json"


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (BASE_DIR / "reports").mkdir(parents=True, exist_ok=True)


def _atomic_write(path: Path, text: str) -> None:
    ensure_dirs()
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try: os.unlink(temp_name)
        except OSError: pass
        raise


def load_records() -> list[dict]:
    ensure_dirs()
    if not DATA_FILE.exists():
        save_records([])
        return []
    try:
        raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("Expected a JSON list of records.")
        records = []
        for item in raw:
            if isinstance(item, dict) and item.get("id"):
                records.append(item)
        return records
    except (json.JSONDecodeError, OSError, ValueError):
        if DATA_FILE.exists():
            try:
                _atomic_write(BACKUP_FILE, DATA_FILE.read_text(encoding="utf-8"))
            except OSError:
                pass
        save_records([])
        return []


def save_records(records: list[dict]) -> None:
    ensure_dirs()
    _atomic_write(DATA_FILE, json.dumps(records, indent=2, ensure_ascii=False))
    _atomic_write(CSV_FILE, export_records_csv(records))


def export_records_csv(records: list[dict]) -> str:
    fields = ["id", "title", "language", "difficulty", "status", "code", "explanation", "notes", "tags", "created_at", "updated_at"]
    from io import StringIO
    buffer = StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for record in records:
        row = dict(record)
        row["tags"] = ",".join(row.get("tags", []))
        writer.writerow(row)
    return buffer.getvalue()


def import_csv_text(content: str) -> tuple[list[dict], list[dict]]:
    if len(content) > 2_000_000:
        raise ValueError("CSV file is too large (maximum 2 MB).")
    from io import StringIO
    reader = csv.DictReader(StringIO(content))
    if not reader.fieldnames:
        raise ValueError("CSV must include a header row.")
    required = {"title"}
    if not required.issubset({name.strip().lower() for name in reader.fieldnames if name}):
        raise ValueError("CSV must include a 'title' column.")
    current = load_records()
    existing_ids = {r["id"] for r in current}
    imported, errors = [], []
    for row_number, row in enumerate(reader, start=2):
        try:
            normalized = {str(k).strip().lower(): (v or "") for k, v in row.items() if k}
            payload = {
                "title": normalized.get("title", ""),
                "language": normalized.get("language", "Python") or "Python",
                "difficulty": normalized.get("difficulty", "Beginner") or "Beginner",
                "status": normalized.get("status", "Draft") or "Draft",
                "code": normalized.get("code", ""),
                "explanation": normalized.get("explanation", ""),
                "notes": normalized.get("notes", ""),
                "tags": normalized.get("tags", ""),
            }
            record = validate_record(payload)
            if record["id"] in existing_ids:
                record["id"] = ""
            record["id"] = record["id"] or __import__("uuid").uuid4().hex
            existing_ids.add(record["id"])
            imported.append(record)
        except Exception as exc:
            errors.append({"row": row_number, "error": str(exc)[:250]})
    if imported:
        save_records(current + imported)
    return imported, errors


def markdown_report(records: list[dict], summary: dict) -> str:
    lines = ["# AI Code Explanation Notebook — Summary Report", "", f"Generated: {datetime.now().isoformat(timespec='seconds')}", "", "## Executive Summary", f"- Total records: {summary['total']}", f"- Average code length: {summary['average_lines']} lines", "", "## Status Breakdown"]
    lines.extend(f"- {status}: {count}" for status, count in summary["statuses"].items())
    lines += ["", "## Records"]
    for r in records:
        lines += [f"### {r.get('title', 'Untitled')}", f"- Language: {r.get('language', 'Other')}", f"- Difficulty: {r.get('difficulty', 'Beginner')}", f"- Status: {r.get('status', 'Draft')}", f"- Tags: {', '.join(r.get('tags', []))}", "", r.get("explanation", "No explanation recorded."), ""]
    return "\n".join(lines)
