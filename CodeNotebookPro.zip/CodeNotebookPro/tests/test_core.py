import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from checklist import validate_record, analyze_python, summarize, filter_records

class ValidationTests(unittest.TestCase):
    def test_valid_record(self):
        r = validate_record({"title":"Example", "code":"print('ok')", "tags":"demo, python"})
        self.assertEqual(r["title"], "Example")
        self.assertEqual(r["tags"], ["demo", "python"])
        self.assertTrue(r["id"] == "")

    def test_blank_title_rejected(self):
        with self.assertRaises(ValueError):
            validate_record({"title":"   "})

    def test_bad_status_rejected(self):
        with self.assertRaises(ValueError):
            validate_record({"title":"x", "status":"Done"})

    def test_length_limit(self):
        with self.assertRaises(ValueError):
            validate_record({"title":"x", "code":"x" * 30001})

class AnalyzerTests(unittest.TestCase):
    def test_valid_python_structure(self):
        a = analyze_python("def f(x):\n    if x:\n        return 1\n    return 0")
        self.assertTrue(a["valid_syntax"])
        self.assertEqual(a["function_count"], 1)
        self.assertGreaterEqual(a["branch_count"], 1)

    def test_syntax_error_is_reported(self):
        a = analyze_python("def broken(:")
        self.assertFalse(a["valid_syntax"])
        self.assertTrue(a["issues"])

    def test_dynamic_execution_warning(self):
        a = analyze_python("eval('2 + 2')")
        self.assertTrue(any("eval" in issue for issue in a["issues"]))

    def test_empty_code(self):
        self.assertFalse(analyze_python("")["valid_syntax"] is False)

class SummaryTests(unittest.TestCase):
    def test_summary_and_filter(self):
        records = [
            {"title":"alpha", "language":"Python", "status":"Reviewed", "difficulty":"Beginner", "code":"x=1", "created_at":"2026-01-01"},
            {"title":"beta", "language":"JavaScript", "status":"Draft", "difficulty":"Advanced", "code":"x=2\ny=3", "created_at":"2026-01-01"},
        ]
        s = summarize(records)
        self.assertEqual(s["total"], 2)
        self.assertEqual(s["average_lines"], 1.5)
        self.assertEqual(len(filter_records(records, "alpha", "All", "All")), 1)
        self.assertEqual(len(filter_records(records, "", "Reviewed", "All")), 1)

if __name__ == "__main__":
    unittest.main(verbosity=2)
