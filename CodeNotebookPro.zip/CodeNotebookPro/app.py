"""Local web application for AI Code Explanation Notebook."""
from __future__ import annotations
import json, mimetypes, uuid
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
from checklist import validate_record, analyze_python, build_improvement_plan, summarize, filter_records
from storage import load_records, save_records, import_csv_text, markdown_report, export_records_csv, BASE_DIR

STATIC = BASE_DIR / "static"
MAX_BODY = 2_100_000

class NotebookHandler(BaseHTTPRequestHandler):
    server_version = "CodeNotebookPro/1.0"

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, content, content_type="text/plain; charset=utf-8", filename=None):
        body = content.encode("utf-8") if isinstance(content, str) else content
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > MAX_BODY:
            raise ValueError("Request body is too large.")
        raw = self.rfile.read(length)
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Request body must be valid JSON.")

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        try:
            if path == "/":
                return self.serve_static("index.html")
            if path in ("/styles.css", "/app.js"):
                return self.serve_static(path.lstrip("/"))
            records = load_records()
            if path == "/api/records":
                q = parse_qs(parsed.query)
                filtered = filter_records(records, q.get("q", [""])[0], q.get("status", ["All"])[0], q.get("language", ["All"])[0])
                return self.send_json({"records": filtered, "summary": summarize(records)})
            if path == "/api/summary":
                return self.send_json({"summary": summarize(records)})
            if path == "/api/export.csv":
                return self.send_text(export_records_csv(records), "text/csv; charset=utf-8", "code-notebook-records.csv")
            if path == "/api/export.json":
                return self.send_text(json.dumps(records, indent=2, ensure_ascii=False), "application/json; charset=utf-8", "code-notebook-backup.json")
            if path == "/api/report.md":
                return self.send_text(markdown_report(records, summarize(records)), "text/markdown; charset=utf-8", "code-notebook-report.md")
            if path == "/api/chart.png":
                return self.serve_chart(records)
            if path.startswith("/api/records/"):
                record_id = path.rsplit("/", 1)[-1]
                record = next((r for r in records if r["id"] == record_id), None)
                if record:
                    return self.send_json({"record": record, "analysis": analyze_python(record.get("code", ""))})
                return self.send_json({"error": "Record not found."}, 404)
            return self.send_json({"error": "Endpoint not found."}, 404)
        except Exception as exc:
            return self.send_json({"error": str(exc)[:300] or "Request failed."}, 500)

    def serve_static(self, filename):
        allowed = {"index.html", "styles.css", "app.js"}
        if filename not in allowed:
            return self.send_json({"error": "File not found."}, 404)
        path = STATIC / filename
        if not path.is_file():
            return self.send_json({"error": "Static file missing."}, 404)
        content = path.read_bytes()
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        if filename.endswith((".html", ".css", ".js")):
            ctype += "; charset=utf-8"
        self.send_text(content, ctype)

    def serve_chart(self, records):
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            return self.send_json({"error": "Matplotlib is not installed. Install requirements.txt."}, 503)
        summary = summarize(records)
        labels = list(summary["statuses"].keys())
        values = [summary["statuses"][key] for key in labels]
        fig, ax = plt.subplots(figsize=(8, 4.4), dpi=150)
        ax.bar(labels, values, color=["#7c5ce7", "#3d7ee8", "#20ad72", "#f0a23b"][:len(labels)])
        ax.set_title("Notebook Records by Review Status", fontsize=14, pad=16)
        ax.set_ylabel("Number of records")
        ax.grid(axis="y", alpha=.18)
        ax.set_axisbelow(True)
        fig.tight_layout()
        from io import BytesIO
        buffer = BytesIO()
        fig.savefig(buffer, format="png", bbox_inches="tight")
        plt.close(fig)
        return self.send_text(buffer.getvalue(), "image/png", "notebook-status-chart.png")

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            payload = self.read_json()
            records = load_records()
            if path == "/api/records":
                record = validate_record(payload)
                record["id"] = uuid.uuid4().hex
                records.append(record)
                save_records(records)
                return self.send_json({"record": record}, 201)
            if path == "/api/import":
                content = payload.get("csv", "")
                if not isinstance(content, str):
                    raise ValueError("CSV content must be text.")
                imported, errors = import_csv_text(content)
                return self.send_json({"imported": len(imported), "errors": errors, "summary": summarize(load_records())})
            if path == "/api/analyze":
                code = payload.get("code", "")
                if not isinstance(code, str) or len(code) > 30000:
                    raise ValueError("Code must be text up to 30,000 characters.")
                analysis = analyze_python(code) if payload.get("language", "Python") == "Python" else {"valid_syntax": None, "summary": "Static AST analysis is available for Python only.", "suggestions": ["Use your course-approved checker for this language."], "issues": []}
                return self.send_json({"analysis": analysis})
            if path == "/api/plan":
                record = validate_record(payload)
                analysis = analyze_python(record.get("code", "")) if record.get("language") == "Python" else {"valid_syntax": None, "issues": []}
                return self.send_json({"plan": build_improvement_plan(record, analysis), "analysis": analysis})
            if path.startswith("/api/records/") and path.endswith("/update"):
                record_id = path.split("/")[3]
                index = next((i for i, r in enumerate(records) if r["id"] == record_id), None)
                if index is None:
                    return self.send_json({"error": "Record not found."}, 404)
                updated = validate_record(payload, records[index])
                updated["id"] = record_id
                records[index] = updated
                save_records(records)
                return self.send_json({"record": updated})
            return self.send_json({"error": "Endpoint not found."}, 404)
        except ValueError as exc:
            return self.send_json({"error": str(exc)}, 400)
        except Exception as exc:
            return self.send_json({"error": str(exc)[:300] or "Request failed."}, 500)

    def do_DELETE(self):
        path = urlparse(self.path).path
        if not path.startswith("/api/records/"):
            return self.send_json({"error": "Endpoint not found."}, 404)
        record_id = path.rsplit("/", 1)[-1]
        records = load_records()
        filtered = [r for r in records if r.get("id") != record_id]
        if len(filtered) == len(records):
            return self.send_json({"error": "Record not found."}, 404)
        save_records(filtered)
        return self.send_json({"deleted": True, "summary": summarize(filtered)})


def main():
    host, port = "127.0.0.1", 8000
    server = ThreadingHTTPServer((host, port), NotebookHandler)
    print("\n  AI Code Explanation Notebook")
    print(f"  Website: http://{host}:{port}")
    print("  Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
