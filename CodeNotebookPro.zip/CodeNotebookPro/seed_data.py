"""Generate 40 realistic starter records for the required demo dataset."""
import uuid
from checklist import validate_record
from storage import load_records, save_records

EXAMPLES = [
("Word count with split", "Python", "Beginner", "text = input('Sentence: ').strip()\nwords = text.split()\nprint(len(words))", "split() separates whitespace-delimited words; an empty or whitespace-only sentence produces zero words.", "Boundary: empty input; one word; repeated spaces.", ["strings", "input"]),
("Safe division helper", "Python", "Beginner", "def divide(a, b):\n    if b == 0:\n        raise ValueError('denominator cannot be zero')\n    return a / b", "A function returns the quotient and explicitly rejects a zero denominator.", "Test positive, negative, zero numerator and zero denominator.", ["functions", "validation"]),
("Temperature range check", "Python", "Beginner", "def in_range(value, low, high):\n    return low <= value <= high", "Inclusive comparisons include both boundary values.", "Test exactly low and high, below low and above high.", ["conditions", "boundary"]),
("List average", "Python", "Beginner", "def average(values):\n    if not values:\n        return None\n    return sum(values) / len(values)", "The helper avoids division by zero for an empty list.", "Test empty, one value and multiple values.", ["lists", "math"]),
("CSV row validation", "Python", "Intermediate", "def valid_row(row):\n    return bool(row.get('title', '').strip())", "A row is accepted only when its title is present and nonblank.", "Test missing title, blank title and valid title.", ["csv", "validation"]),
("Search by keyword", "Python", "Beginner", "def matches(text, query):\n    return query.casefold() in text.casefold()", "casefold() supports case-insensitive matching for many languages.", "Test empty query and mixed-case words.", ["search", "strings"]),
("Factorial iterative", "Python", "Intermediate", "def factorial(n):\n    if n < 0:\n        raise ValueError('n must be non-negative')\n    result = 1\n    for value in range(2, n + 1):\n        result *= value\n    return result", "An iterative product computes factorial while rejecting negative values.", "Boundary: factorial(0) is 1; check negative input.", ["loops", "math"]),
("Unique values preserving order", "Python", "Intermediate", "def unique(items):\n    seen = set()\n    result = []\n    for item in items:\n        if item not in seen:\n            seen.add(item)\n            result.append(item)\n    return result", "A set tracks membership while a list preserves first-seen order.", "Test empty list, repeated values and mixed values.", ["sets", "lists"]),
]


def main():
    current = load_records()
    if current:
        print(f"Dataset already contains {len(current)} records; no changes made.")
        return
    records = []
    for i in range(40):
        title, language, difficulty, code, explanation, notes, tags = EXAMPLES[i % len(EXAMPLES)]
        variants = ["normal case", "minimum boundary", "maximum boundary", "invalid input", "empty input"]
        record = validate_record({
            "title": f"{title} — Scenario {i + 1:02d}",
            "language": language,
            "difficulty": difficulty,
            "status": ["Draft", "Reviewed", "Improved", "Draft"][i % 4],
            "code": code,
            "explanation": explanation,
            "notes": f"Dataset scenario: {variants[i % len(variants)]}. {notes}",
            "tags": tags,
        })
        record["id"] = uuid.uuid4().hex
        records.append(record)
    save_records(records)
    print("Created 40 sample notebook records (normal, boundary and edge-case scenarios).")

if __name__ == "__main__":
    main()
