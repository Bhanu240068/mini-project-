# CodeLens Notebook — AI Code Explanation Notebook

**Project #120 | LocalImpact Challenge | AI, APIs & Smart Applications**

A beginner-friendly, local-first Python application for collecting small code examples, explaining them, reviewing improvement suggestions, recording tests, and preparing reports. It includes a polished responsive web UI and a menu-driven terminal interface.

> The app does not claim to be connected to an AI service. It provides a structured workflow for using an approved AI assistant, and a static Python AST analyzer that never executes pasted code. Users should review suggestions, test them in their course-approved environment, and document outcomes.

## Features mapped to the project brief

### Core features
- Interactive terminal menu (`cli.py`) for add, search, analysis, summary and improvement workflow.
- Defensive validation for required fields, length limits, allowed language/difficulty/status values, tag limits and request size.
- Core code-learning workflow: explain → ask approved AI assistant → review → test normal/boundary/invalid cases → document.
- Local JSON persistence with atomic replacement and automatic CSV synchronization; recovery path for malformed JSON.
- Keyword, status and language filters.
- Executive summary: totals, status distribution, difficulty/language counts, average code lines and today's records.
- Matplotlib chart export (`/api/chart.png`) and in-page status chart.

### Stretch features
- Markdown report, plain JSON backup and CSV dataset downloads.
- Review warning signals for unsafe dynamic Python calls and syntax issues.
- Responsive GUI-style web interface.
- Bulk CSV import with per-row errors while importing valid rows.
- 40-record sample dataset with normal, boundary and edge-case scenarios.
- Unit tests for validation, analyzer, filtering and summary logic.

## Project structure

```text
CodeNotebookPro/
├── app.py                 # Local HTTP server and API routes
├── checklist.py           # Validation, analysis, workflow and summaries
├── storage.py             # JSON/CSV persistence and report generation
├── cli.py                 # Terminal interface
├── seed_data.py            # Optional 40-record demo dataset
├── requirements.txt         # Matplotlib dependency
├── data/                   # Local records (created automatically)
├── reports/                # Reserved for generated reports
├── static/
│   ├── index.html
│   ├── styles.css
│   └── app.js
└── tests/test_core.py
```

## Run in VS Code

1. Extract the ZIP and open the `CodeNotebookPro` folder in VS Code.
2. Use Python 3.10 or newer.
3. Optional: create and activate a virtual environment.

   ```bash
   python -m venv .venv
   ```

   Windows PowerShell:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

4. Install chart support:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Optional: create the sample dataset (40 records):

   ```bash
   python seed_data.py
   ```

6. Start the website:

   ```bash
   python app.py
   ```

7. Open **http://127.0.0.1:8000** in your browser. Stop with `Ctrl+C`.

### Terminal interface

In another terminal run:

```bash
python cli.py
```

### Automated tests

```bash
python -m unittest discover -s tests -v
```

## CSV format

The import expects a header containing `title`. Optional columns: `language`, `difficulty`, `status`, `code`, `explanation`, `notes`, and `tags`. Tags may be comma-separated. Import validates each row and reports invalid rows separately.

## Safety and reliability

- Pasted code is analyzed as text and parsed with Python's `ast`; it is never executed by the app.
- The built-in static analyzer only analyzes Python. Other languages are stored and documented, but use a course-approved language-specific checker for syntax/behavior tests.
- Use localhost only. The server binds to `127.0.0.1`, not a public network interface.
- Never paste passwords, API keys, private data or confidential source code into a notebook record or external AI assistant.
- JSON is written atomically to reduce the chance of partial-file corruption. CSV is regenerated from the current records.

## Rubric alignment checklist (100-point rubric)

| Rubric category | Project evidence |
|---|---|
| Requirements Fulfilment (25) | All core features, CLI, import/export, summaries, chart, 40 sample records |
| Code Quality & Best Practices (20) | Modular files, functions, validation, naming, comments, tests |
| Functionality & Reliability (20) | CRUD, filtering, analyzer, JSON/CSV persistence, recovery and row-level import errors |
| System Design & Architecture (20) | UI/API/domain/storage separation, static assets, API routes, reusable logic |
| Security & Robustness (10) | Local-only binding, body limits, validation, output escaping, non-executing code analyzer |
| Innovation & Technical Complexity (5) | Code structure analysis, improvement workflow, analytics, chart and audit-style notes |

The LMS evaluator controls the final score. This project is designed to address the rubric, but no score can be guaranteed.
