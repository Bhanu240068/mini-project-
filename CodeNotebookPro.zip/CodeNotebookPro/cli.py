"""Interactive terminal interface for the notebook project."""
from checklist import validate_record, summarize, analyze_python, build_improvement_plan, filter_records
from storage import load_records, save_records
import uuid


def ask(prompt, required=True, max_len=120):
    while True:
        value = input(prompt).strip()
        if required and not value:
            print("Please enter a value.")
            continue
        if len(value) > max_len:
            print(f"Keep input within {max_len} characters.")
            continue
        return value


def add_record(records):
    print("\nNew notebook record")
    title = ask("Title: ")
    language = ask("Language [Python]: ", required=False) or "Python"
    difficulty = ask("Difficulty [Beginner/Intermediate/Advanced]: ")
    print("Paste code; finish with a line containing only .END")
    lines = []
    while True:
        line = input()
        if line == ".END":
            break
        lines.append(line)
        if sum(map(len, lines)) > 30000:
            print("Code size limit reached.")
            return
    payload = {"title": title, "language": language, "difficulty": difficulty, "code": "\n".join(lines), "status": "Draft"}
    try:
        record = validate_record(payload)
        record["id"] = uuid.uuid4().hex
        records.append(record)
        save_records(records)
        print("Saved record.")
    except ValueError as exc:
        print(f"Validation error: {exc}")


def main():
    records = load_records()
    while True:
        print("\n=== AI CODE EXPLANATION NOTEBOOK ===")
        print("1. Add record  2. List/search  3. Analyze Python  4. Summary")
        print("5. Save improvement plan  6. Exit")
        choice = input("Select: ").strip()
        if choice == "1":
            add_record(records)
            records = load_records()
        elif choice == "2":
            query = input("Search keyword (blank for all): ").strip()
            found = filter_records(records, query)
            for r in found:
                print(f"{r['id'][:8]} | {r['title']} | {r['language']} | {r['status']}")
            if not found:
                print("No matching records.")
        elif choice == "3":
            print("Paste Python code; finish with .END")
            code = []
            while True:
                line = input()
                if line == ".END": break
                code.append(line)
            print(analyze_python("\n".join(code)))
        elif choice == "4":
            print(summarize(records))
        elif choice == "5":
            if not records:
                print("Create a record first.")
                continue
            for i, r in enumerate(records, 1): print(f"{i}. {r['title']}")
            try: selected = records[int(input("Record number: ")) - 1]
            except (ValueError, IndexError): print("Invalid selection."); continue
            analysis = analyze_python(selected.get("code", ""))
            print("\n".join(build_improvement_plan(selected, analysis)))
        elif choice == "6":
            print("Goodbye.")
            break
        else:
            print("Choose a menu option from 1 to 6.")

if __name__ == "__main__":
    main()
