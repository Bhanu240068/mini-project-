"""Domain logic for AI Code Explanation Notebook."""
from __future__ import annotations

import ast
import re
from datetime import date, datetime
from typing import Any

STATUSES = {"Draft", "Reviewed", "Improved", "Archived"}
DIFFICULTIES = {"Beginner", "Intermediate", "Advanced"}
LANGUAGES = {"Python", "JavaScript", "Java", "C", "C++", "Other"}
MAX_CODE_LENGTH = 30_000


def clean_text(value: Any, field: str, limit: int = 120, required: bool = True) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text.")
    value = value.strip()
    if required and not value:
        raise ValueError(f"{field} is required.")
    if len(value) > limit:
        raise ValueError(f"{field} must be {limit} characters or fewer.")
    if any(ord(ch) < 32 and ch not in "\n\r\t" for ch in value):
        raise ValueError(f"{field} contains unsupported control characters.")
    return value


def validate_record(payload: dict[str, Any], existing: dict[str, Any] | None = None) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Record must be a JSON object.")
    title = clean_text(payload.get("title", ""), "Title", 100)
    language = clean_text(payload.get("language", "Python"), "Language", 30)
    if language not in LANGUAGES:
        raise ValueError("Choose a supported language.")
    difficulty = clean_text(payload.get("difficulty", "Beginner"), "Difficulty", 20)
    if difficulty not in DIFFICULTIES:
        raise ValueError("Choose a supported difficulty.")
    status = clean_text(payload.get("status", "Draft"), "Status", 20)
    if status not in STATUSES:
        raise ValueError("Choose a supported status.")
    code = clean_text(payload.get("code", ""), "Code", MAX_CODE_LENGTH, required=False)
    explanation = clean_text(payload.get("explanation", ""), "Explanation", 5000, required=False)
    notes = clean_text(payload.get("notes", ""), "Test / improvement notes", 3000, required=False)
    tags_raw = payload.get("tags", "")
    if isinstance(tags_raw, list):
        tags = [clean_text(str(tag), "Tag", 24) for tag in tags_raw if str(tag).strip()]
    elif isinstance(tags_raw, str):
        tags = [clean_text(tag, "Tag", 24) for tag in tags_raw.split(",") if tag.strip()]
    else:
        raise ValueError("Tags must be text or a list.")
    tags = list(dict.fromkeys(tags))[:10]
    created = (existing or {}).get("created_at") or datetime.now().isoformat(timespec="seconds")
    record_id = (existing or {}).get("id")
    if not record_id:
        record_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(payload.get("id", "")))[:40]
    return {
        "id": record_id,
        "title": title,
        "language": language,
        "difficulty": difficulty,
        "status": status,
        "code": code,
        "explanation": explanation,
        "notes": notes,
        "tags": tags,
        "created_at": created,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }


def analyze_python(code: str) -> dict[str, Any]:
    """Static, non-executing Python analysis. Never runs submitted code."""
    result: dict[str, Any] = {
        "valid_syntax": True, "line_count": len(code.splitlines()),
        "function_count": 0, "class_count": 0, "loop_count": 0,
        "branch_count": 0, "imports": [], "complexity": 1,
        "issues": [], "suggestions": [], "summary": "No code provided.",
    }
    if not code.strip():
        result["suggestions"] = ["Add a small, clearly named code example to begin analysis."]
        return result
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        result["valid_syntax"] = False
        result["issues"].append(f"Syntax error on line {exc.lineno or '?'}: {exc.msg}")
        result["suggestions"].append("Review indentation, brackets, colons and spelling around the reported line.")
        result["summary"] = "Python syntax needs attention before further review."
        return result
    functions = [node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
    loops = [node for node in ast.walk(tree) if isinstance(node, (ast.For, ast.AsyncFor, ast.While))]
    branches = [node for node in ast.walk(tree) if isinstance(node, (ast.If, ast.IfExp, ast.Match))]
    result.update(function_count=len(functions), class_count=len(classes), loop_count=len(loops), branch_count=len(branches))
    result["complexity"] = 1 + len(loops) + len(branches) + sum(len(node.handlers) for node in ast.walk(tree) if isinstance(node, ast.Try))
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module)
    result["imports"] = sorted(set(imports))
    risky = {"eval", "exec", "compile", "__import__"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in risky:
            result["issues"].append(f"Review use of {node.func.id}(): dynamic execution can be unsafe.")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "input":
            result["suggestions"].append("Validate user input and handle blank or unexpected values.")
    if not functions and len(code.splitlines()) > 12:
        result["suggestions"].append("Consider extracting repeated or logically separate steps into functions.")
    if functions and any(len(ast.get_source_segment(code, fn) or "") > 900 for fn in functions):
        result["suggestions"].append("Consider splitting long functions into smaller, single-purpose helpers.")
    if not any(isinstance(node, ast.Try) for node in ast.walk(tree)):
        result["suggestions"].append("Add appropriate exception handling around file and user-input operations.")
    if not result["suggestions"]:
        result["suggestions"].append("Review edge cases and add tests for normal, boundary and invalid inputs.")
    result["summary"] = (
        f"Valid Python syntax. Found {result['function_count']} function(s), "
        f"{result['class_count']} class(es), {result['loop_count']} loop(s), "
        f"and {result['branch_count']} branch(es)."
    )
    return result


def build_improvement_plan(record: dict[str, Any], analysis: dict[str, Any]) -> list[str]:
    plan = [
        "Describe the program's purpose and expected input/output in one or two sentences.",
        "Ask your approved AI assistant for a small, explainable improvement; avoid sharing private data or credentials.",
        "Compare the suggestion with the original code and keep only changes you understand.",
        "Test normal cases, boundary values and invalid inputs; record the observed results in Test / improvement notes.",
        "Update the explanation and status after review; retain the original version separately if needed.",
    ]
    if not analysis.get("valid_syntax", True):
        plan.insert(0, "Fix the syntax issue reported by the static analyzer before reviewing behavior.")
    if analysis.get("issues"):
        plan.insert(1, "Review the safety warnings and replace risky dynamic execution where possible.")
    if record.get("language") != "Python":
        plan.append("The built-in AST analysis applies only to Python; use your course-approved checker for this language.")
    return plan


def summarize(records: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(records)
    statuses = {status: sum(1 for r in records if r.get("status") == status) for status in sorted(STATUSES)}
    difficulties = {level: sum(1 for r in records if r.get("difficulty") == level) for level in sorted(DIFFICULTIES)}
    languages: dict[str, int] = {}
    for record in records:
        language = record.get("language", "Other")
        languages[language] = languages.get(language, 0) + 1
    average_lines = round(sum(len(r.get("code", "").splitlines()) for r in records) / total, 1) if total else 0
    return {
        "total": total,
        "statuses": statuses,
        "difficulties": difficulties,
        "languages": languages,
        "average_lines": average_lines,
        "today_created": sum(1 for r in records if str(r.get("created_at", ""))[:10] == date.today().isoformat()),
    }


def filter_records(records: list[dict[str, Any]], query: str = "", status: str = "All", language: str = "All") -> list[dict[str, Any]]:
    query = query.casefold().strip()
    result = []
    for record in records:
        if status != "All" and record.get("status") != status:
            continue
        if language != "All" and record.get("language") != language:
            continue
        haystack = " ".join([record.get("title", ""), record.get("explanation", ""), record.get("language", ""), " ".join(record.get("tags", []))]).casefold()
        if query and query not in haystack:
            continue
        result.append(record)
    return sorted(result, key=lambda r: r.get("updated_at", ""), reverse=True)
